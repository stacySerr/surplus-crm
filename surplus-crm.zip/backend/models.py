# Pydantic models placeholder
