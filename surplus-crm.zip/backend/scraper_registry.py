# Scraper registry placeholder
